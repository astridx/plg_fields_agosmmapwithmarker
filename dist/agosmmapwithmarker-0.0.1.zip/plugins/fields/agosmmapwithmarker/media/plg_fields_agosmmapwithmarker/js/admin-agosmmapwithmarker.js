document.addEventListener('DOMContentLoaded', function () {
    var placesAutocomplete = places({
        container: document.querySelector(".address-input")
    });
}, false);